(function() {
    var PREFIX = '/';

    function createMenu() {
        var headerContainer = document.querySelector('.header__container');
        if (!headerContainer) return;

        headerContainer.innerHTML = '';

        var sidebarToggle = document.createElement('button');
        sidebarToggle.className = 'sidebar-toggle';
        sidebarToggle.id = 'sidebarToggle';
        sidebarToggle.setAttribute('aria-label', 'Открыть боковое меню');
        sidebarToggle.innerHTML = '<span class="sidebar-icon"></span>';
        headerContainer.appendChild(sidebarToggle);

        var logo = document.createElement('a');
        logo.className = 'header__logo';
        logo.href = PREFIX + 'index.html';
        logo.textContent = 'Millerson Company';
        headerContainer.appendChild(logo);

        var burger = document.createElement('button');
        burger.className = 'burger';
        burger.id = 'burgerBtn';
        burger.setAttribute('aria-label', 'Открыть меню');
        for (var i = 0; i < 3; i++) {
            var line = document.createElement('span');
            line.className = 'burger__line';
            burger.appendChild(line);
        }
        headerContainer.appendChild(burger);

        var pages = [
            { href: PREFIX + 'index.html', text: 'Главная', icon: 'fas fa-home' },
            { href: PREFIX + 'all.html', text: 'Все проекты', icon: 'fas fa-th-large' },
            { href: PREFIX + 'about.html', text: 'О компании', icon: 'fas fa-info-circle' },
            { href: PREFIX + 'contacts.html', text: 'Контакты', icon: 'fas fa-envelope' }
        ];

        // === SIDEBAR (desktop) ===
        var sidebar = document.createElement('nav');
        sidebar.className = 'sidebar';
        sidebar.id = 'sidebar';
        sidebar.setAttribute('aria-label', 'Основная навигация');

        var sidebarClose = document.createElement('button');
        sidebarClose.className = 'sidebar__close';
        sidebarClose.id = 'sidebarClose';
        sidebarClose.setAttribute('aria-label', 'Закрыть меню');
        sidebarClose.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>';
        sidebar.appendChild(sidebarClose);

        var sidebarLogo = document.createElement('div');
        sidebarLogo.className = 'sidebar__logo';
        sidebarLogo.innerHTML = '<span class="sidebar__logo-text">Millerson</span>';
        sidebar.appendChild(sidebarLogo);

        var navTitle = document.createElement('div');
        navTitle.className = 'sidebar__section-title';
        navTitle.textContent = 'Навигация';
        sidebar.appendChild(navTitle);

        var navList = document.createElement('ul');
        navList.className = 'sidebar__nav-list';
        pages.forEach(function(p) {
            var li = document.createElement('li');
            var a = document.createElement('a');
            a.href = p.href;
            a.className = 'sidebar__nav-link';
            a.innerHTML = '<i class="' + p.icon + '"></i> ' + p.text;
            li.appendChild(a);
            navList.appendChild(li);
        });
        sidebar.appendChild(navList);

        var divider1 = document.createElement('div');
        divider1.className = 'sidebar__divider';
        sidebar.appendChild(divider1);

        var settingsTitle = document.createElement('div');
        settingsTitle.className = 'sidebar__section-title';
        settingsTitle.textContent = 'Настройки';
        sidebar.appendChild(settingsTitle);

        var themeDiv = document.createElement('div');
        themeDiv.className = 'sidebar__toggle-item';
        themeDiv.innerHTML = '<span>Тёмная тема</span><label class="switch"><input type="checkbox" id="themeToggleSidebar"><span class="slider"></span></label>';
        sidebar.appendChild(themeDiv);

        var simpleDiv = document.createElement('div');
        simpleDiv.className = 'sidebar__toggle-item';
        simpleDiv.innerHTML = '<span>Супер-простой режим</span><label class="switch"><input type="checkbox" id="simpleModeSidebar"><span class="slider"></span></label>';
        sidebar.appendChild(simpleDiv);

        var precisionDiv = document.createElement('div');
        precisionDiv.className = 'sidebar__toggle-item';
        precisionDiv.innerHTML = '<span>Точность</span><select id="precisionSelectSidebar"><option value="2" selected>2 знака</option><option value="4">4 знака</option><option value="6">6 знаков</option></select>';
        sidebar.appendChild(precisionDiv);

        var divider2 = document.createElement('div');
        divider2.className = 'sidebar__divider';
        sidebar.appendChild(divider2);

        var kworkDiv = document.createElement('div');
        kworkDiv.className = 'sidebar__kwork';
        var kworkA = document.createElement('a');
        kworkA.href = 'https://kwork.ru/user/Millerson_Shop';
        kworkA.target = '_blank';
        kworkA.rel = 'noopener';
        kworkA.className = 'btn btn--primary sidebar__kwork-btn';
        kworkA.innerHTML = '<i class="fas fa-briefcase"></i> Millerson SHOP';
        kworkDiv.appendChild(kworkA);
        sidebar.appendChild(kworkDiv);

        document.body.appendChild(sidebar);

        var overlay = document.createElement('div');
        overlay.className = 'sidebar-overlay';
        overlay.id = 'sidebarOverlay';
        document.body.appendChild(overlay);

        // === MOBILE NAV ===
        var mobileNav = document.createElement('nav');
        mobileNav.className = 'nav nav--mobile';
        mobileNav.id = 'navMobile';
        var mobileUl = document.createElement('ul');
        mobileUl.className = 'nav__list';

        pages.forEach(function(p) {
            var li = document.createElement('li');
            var a = document.createElement('a');
            a.href = p.href;
            a.className = 'nav__link';
            a.textContent = p.text;
            li.appendChild(a);
            mobileUl.appendChild(li);
        });

        var mobileThemeLi = document.createElement('li');
        mobileThemeLi.innerHTML = '<div class="theme-switch"><span class="theme-switch__label">Тёмная тема</span><label class="switch"><input type="checkbox" id="themeToggleMobile"><span class="slider"></span></label></div>';
        mobileUl.appendChild(mobileThemeLi);

        var mobileSimpleLi = document.createElement('li');
        mobileSimpleLi.innerHTML = '<div class="theme-switch"><span class="theme-switch__label">Супер-простой режим</span><label class="switch"><input type="checkbox" id="simpleModeToggleMobile"><span class="slider"></span></label></div>';
        mobileUl.appendChild(mobileSimpleLi);

        var mobilePrecisionLi = document.createElement('li');
        mobilePrecisionLi.className = 'precision-selector';
        mobilePrecisionLi.innerHTML = '<span>Точность:</span><select id="precisionSelectMobile"><option value="2" selected>2</option><option value="4">4</option><option value="6">6</option></select>';
        mobileUl.appendChild(mobilePrecisionLi);

        var mobileKworkLi = document.createElement('li');
        var mobileKworkA = document.createElement('a');
        mobileKworkA.href = 'https://kwork.ru/user/Millerson_Shop';
        mobileKworkA.target = '_blank';
        mobileKworkA.rel = 'noopener';
        mobileKworkA.className = 'btn btn--primary';
        mobileKworkA.textContent = 'Millerson SHOP на Kwork';
        mobileKworkLi.appendChild(mobileKworkA);
        mobileUl.appendChild(mobileKworkLi);

        mobileNav.appendChild(mobileUl);
        headerContainer.appendChild(mobileNav);
    }

    createMenu();

    // === SIDEBAR LOGIC ===
    var sidebarToggle = document.getElementById('sidebarToggle');
    var sidebar = document.getElementById('sidebar');
    var sidebarOverlay = document.getElementById('sidebarOverlay');
    var sidebarClose = document.getElementById('sidebarClose');

    function openSidebar() {
        if (sidebar) sidebar.classList.add('active');
        if (sidebarOverlay) sidebarOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function closeSidebar() {
        if (sidebar) sidebar.classList.remove('active');
        if (sidebarOverlay) sidebarOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }
    if (sidebarToggle) sidebarToggle.addEventListener('click', function(e) { e.stopPropagation(); openSidebar(); });
    if (sidebarClose) sidebarClose.addEventListener('click', closeSidebar);
    if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);
    if (sidebar) {
        sidebar.querySelectorAll('.sidebar__nav-link').forEach(function(link) {
            link.addEventListener('click', closeSidebar);
        });
    }

    // === THEME ===
    var themeToggleSidebar = document.getElementById('themeToggleSidebar');
    var themeToggleMobile = document.getElementById('themeToggleMobile');
    var savedTheme = localStorage.getItem('theme');

    function setTheme(checked) {
        if (checked) {
            document.body.classList.add('dark-theme');
        } else {
            document.body.classList.remove('dark-theme');
        }
        localStorage.setItem('theme', checked ? 'dark' : 'light');
        if (themeToggleSidebar) themeToggleSidebar.checked = checked;
        if (themeToggleMobile) themeToggleMobile.checked = checked;
    }

    if (savedTheme !== 'light') {
        setTheme(true);
    } else {
        setTheme(false);
    }

    if (themeToggleSidebar) themeToggleSidebar.addEventListener('change', function(e) { setTheme(e.target.checked); });
    if (themeToggleMobile) themeToggleMobile.addEventListener('change', function(e) { setTheme(e.target.checked); });

    // === BURGER (mobile) ===
    var burgerBtn = document.getElementById('burgerBtn');
    var navMobile = document.getElementById('navMobile');

    function closeMobileMenu() {
        if (navMobile) navMobile.classList.remove('active');
        if (burgerBtn) burgerBtn.classList.remove('active');
        document.body.style.overflow = '';
    }

    if (burgerBtn && navMobile) {
        burgerBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            navMobile.classList.toggle('active');
            burgerBtn.classList.toggle('active');
            document.body.style.overflow = navMobile.classList.contains('active') ? 'hidden' : '';
        });
        navMobile.querySelectorAll('.nav__link, .btn').forEach(function(link) {
            link.addEventListener('click', closeMobileMenu);
        });
        document.addEventListener('click', function(event) {
            if (!navMobile.contains(event.target) && !burgerBtn.contains(event.target)) {
                closeMobileMenu();
            }
        });
    }

    // === SIMPLE MODE ===
    var simpleToggleSidebar = document.getElementById('simpleModeSidebar');
    var simpleToggleMobile = document.getElementById('simpleModeToggleMobile');

    function showGameToast(text) {
        var existingToast = document.querySelector('.game-toast');
        if (existingToast) existingToast.remove();
        var toast = document.createElement('div');
        toast.className = 'game-toast';
        toast.innerHTML = '<span style="flex:1; margin-right:8px;">' + text + '</span><span style="font-size:1.2rem; cursor:pointer;" onclick="this.parentElement.remove()">&#10005;</span>';
        document.body.appendChild(toast);
        setTimeout(function() { if (toast.parentNode) toast.remove(); }, 3500);
    }

    function setSimpleMode(checked) {
        if (checked) {
            document.body.classList.add('simple-mode');
            showGameToast('Супер-простой режим включён');
        } else {
            document.body.classList.remove('simple-mode');
            showGameToast('Супер-простой режим выключен');
        }
        if (simpleToggleSidebar) simpleToggleSidebar.checked = checked;
        if (simpleToggleMobile) simpleToggleMobile.checked = checked;
    }

    if (simpleToggleSidebar) simpleToggleSidebar.addEventListener('change', function(e) { setSimpleMode(e.target.checked); });
    if (simpleToggleMobile) simpleToggleMobile.addEventListener('change', function(e) { setSimpleMode(e.target.checked); });

    // === PRECISION ===
    var precisionSidebar = document.getElementById('precisionSelectSidebar');
    var precisionMobile = document.getElementById('precisionSelectMobile');

    function setPrecision(val) {
        var precision = parseInt(val, 10);
        if (precisionSidebar) precisionSidebar.value = val;
        if (precisionMobile) precisionMobile.value = val;
        window.precision = precision;
        window.dispatchEvent(new CustomEvent('precisionChange', { detail: precision }));
    }

    if (precisionSidebar) precisionSidebar.addEventListener('change', function(e) { setPrecision(e.target.value); });
    if (precisionMobile) precisionMobile.addEventListener('change', function(e) { setPrecision(e.target.value); });

    if (precisionSidebar || precisionMobile) {
        var initialVal = precisionSidebar ? precisionSidebar.value : (precisionMobile ? precisionMobile.value : '2');
        window.precision = parseInt(initialVal, 10);
    } else {
        window.precision = 2;
    }

    // === KEYBOARD ===
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeSidebar();
            closeMobileMenu();
        }
    });
})();
